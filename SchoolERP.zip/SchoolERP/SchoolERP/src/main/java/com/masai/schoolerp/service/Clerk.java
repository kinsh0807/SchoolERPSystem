package com.masai.schoolerp.service;

import com.masai.schoolerp.Daoimpl.FeeDao;
import com.masai.schoolerp.Daoimpl.StudentDao;
import com.masai.schoolerp.entity.Fees_Record;
import com.masai.schoolerp.entity.Student;

import java.util.List;

public class Clerk {
    private StudentDao studentDao;
    private FeeDao feeDao;

    public Clerk(StudentDao studentDao, FeeDao feeDao) {
        this.studentDao = studentDao;
        this.feeDao = feeDao;
    }

    public void createStudent(Student student) {
        studentDao.create(student);
    }

    public Student readStudent(int id) {
        return studentDao.read(id);
    }

    public void updateStudent(Student student) {
        studentDao.update(student);
    }

    public void deleteStudent(int id) {
        studentDao.delete(id);
    }

    public void addFeeRecord(Fees_Record feesRecord) {
        feeDao.create(feesRecord);
    }

    public Fees_Record getFeeRecord(int studentId) {
        return feeDao.read(studentId);
    }

    public void updateFeeRecord(Fees_Record feesRecord) {
        feeDao.update(feesRecord);
    }

    public List<Student> getStudentDetailsByClass(String className) {
        return studentDao.getByClass(className);
    }
}
