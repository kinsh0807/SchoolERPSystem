package com.masai.schoolerp.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Fees_Record {

    private int studentId;
    private float feeAmount;
    private Date dueDate;
    private float paidAmount;

}
