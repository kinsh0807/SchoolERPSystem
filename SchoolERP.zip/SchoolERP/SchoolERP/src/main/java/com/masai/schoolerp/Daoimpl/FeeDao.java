package com.masai.schoolerp.Daoimpl;

import com.masai.schoolerp.entity.Fees_Record;

import java.util.List;

public interface FeeDao {

    void create(Fees_Record feesRecord);
    Fees_Record read(int studentId);
    void update(Fees_Record feesRecord);
    List<Fees_Record> getByClass(String className);
    int getTotalFeesPaidThisMonth(int currentMonth, int currentYear);
}
