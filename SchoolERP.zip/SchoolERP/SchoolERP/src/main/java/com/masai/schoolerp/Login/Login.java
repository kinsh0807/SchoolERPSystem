package com.masai.schoolerp.Login;

import com.masai.schoolerp.Daoimpl.UserDao;
import com.masai.schoolerp.entity.User;

public class Login {
    private UserDao userDao;
    public Login(UserDao userDao) {
        this.userDao = userDao;
    }

    public User login(String username, String password) {
        User user = userDao.getUSerByName(username);
        if (user != null && user.getPassword().equals(password)) {
            System.out.println("User " + username + " logged in");
            return user;
        } else {
            return null;
        }
    }
}
